package com.scommesse.pugbet;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PugbetApplication {

	public static void main(String[] args) {
		SpringApplication.run(PugbetApplication.class, args);
	}
}

