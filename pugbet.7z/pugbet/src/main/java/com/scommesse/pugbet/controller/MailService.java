package com.scommesse.pugbet.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


	
	@Service
	public class MailService {

		/*
		 * JavaMailSender estende l'interfaccia MailSender che contiente la funione send()
		 * E' richiesto l'oggetto SimpleMailMessage che il metodo send() userà un oggetto di tipo SimpleMailMessage come parametro
		 */
		
		private JavaMailSender javaMailSender;

		
		@Autowired
		public MailService(JavaMailSender javaMailSender) {
			this.javaMailSender = javaMailSender;
		}

		@Autowired
		private UtenteService us;
		
		public void sendEmail(Utente utente,HttpSession session) throws MailException {

			String appUrl=(String)session.getAttribute("urlEmail");
			SimpleMailMessage mail = new SimpleMailMessage();
			mail.setTo(utente.getEmail());
			mail.setFrom("adpugbet@gmail.com");
			mail.setSubject("Test");
			mail.setText("To reset your password, click the link below:\n" + appUrl
					+ ":8080/resetPassword?token=" + us.findByEmail(utente.getEmail()).getResetToken());
			session.removeAttribute("urlEmail");
		
			
			javaMailSender.send(mail);
		}

	}

