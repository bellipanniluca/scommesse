package com.scommesse.pugbet.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MailController {
	
	@Autowired
	private MailService notificationService;
	
	@Autowired
	private Utente utente;
	
	@Autowired
	private UtenteService us;

	
	
	@RequestMapping(value="/sendmail", method= RequestMethod.GET)
	@ResponseBody
	public String send(@RequestParam("email")String email,
						HttpServletRequest request,
						HttpSession session,
						ModelMap model) {

		/*
		 *Creazione Utente che riceve la mail grazie alla classe User instanziata precedentemente
		 */
		utente.setNome(us.findByEmail(email).getNome());
		utente.setCognome(us.findByEmail(email).getCognome());
		utente.setEmail(email);
		
		String token=UUID.randomUUID().toString();
		us.findByEmail(email).setResetToken(token);
		us.save(us.findByEmail(email));
		
		String appUrl = request.getScheme() + "://" + request.getServerName();
		session.setAttribute("token", token);
		session.setAttribute("emailReset", email);
		session.setAttribute("urlEmail", appUrl);
		/*
		 * Chiamata del metodo sendEmail per l'invio della mail all'user dichiarato sopra
		 */
		try {
			notificationService.sendEmail(utente,session);
		} catch (MailException mailException) {
			System.out.println(mailException);
		}
		return "Ti abbiamo inviato un token di recupero a "+ email;
	}
	
	@RequestMapping(value = "/reset", method = RequestMethod.GET)
	public String setNewPassword(@RequestParam("passwordReset") String password,
								 @RequestParam("passwordResetConfirm")String passwordConfirm,
								 HttpSession session) {

		// Find the user associated with the reset token
		Utente user = us.findByResetToken((String)session.getAttribute("token"));

		// This should always be non-null but we check just in case
		if (user!=null) {
			
			if(password.equals(passwordConfirm)) {
            
			user.setPw(password);
			// Set the reset token to null so it cannot be used again
			user.setResetToken(null);

			// Save user
			us.save(user);

			session.removeAttribute("token");
			session.removeAttribute("emailReset");
			return "redirect:/login";
			}
			
		} 
		
		return "redirect:/resetPassword";
   }
}
