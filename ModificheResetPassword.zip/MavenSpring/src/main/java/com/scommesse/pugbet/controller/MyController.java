package com.scommesse.pugbet.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.scommesse.pugbet.model.Schedina;


@Controller


public class MyController {
	
	@Autowired
	PartitaCalcioService pcs;
	
	@Autowired
	PartitaBasketService pbs;
	
	@Autowired
	PartitaHockeyService phs;
	
	@Autowired
	UtenteService us;
	
	@Autowired
	AdminService as;
	
	@Autowired
	SchedinaFinaleService sfs;
	
	@RequestMapping(value="/")
	public String showHomePage(Model model, HttpSession session){
		
		
		
		List<PartitaCalcio> p = pcs.findAll();
		model.addAttribute("att", p);
		
		if(session.getAttribute("utente") == null) {
			
			Schedina schedina;
			if(session.getAttribute("schedina") == null) {
				schedina = new Schedina();
			}
			else {
				schedina = (Schedina)session.getAttribute("schedina");
			}
			session.setAttribute("schedina", schedina);
			model.addAttribute("schedina", schedina.getListaGiocate());
			model.addAttribute("quotaTot", schedina.getQuotaTotale());
			return "index";
		}
		else {
			Utente u = (Utente)session.getAttribute("utente");
			Schedina s = (Schedina)session.getAttribute("schedina");
			model.addAttribute("utente", u);
			model.addAttribute("schedina", s.getListaGiocate());
			model.addAttribute("quotaTot", s.getQuotaTotale());
			return "index";
		}
		}
	
	@RequestMapping(value="/prova", method = RequestMethod.GET)
	public void showProvaPage(ModelMap model, HttpServletRequest request, HttpServletResponse response) throws IOException{
		
		response.getWriter().append("provaaaa "+request.getParameter("pa"));
		}
	
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String showLoginPage(ModelMap model){
		return "login";
		}
	
	@RequestMapping(value="/adminLogin", method = RequestMethod.GET)
	public String showAdminLoginPage(ModelMap model){
		return "adminLogin";
		}
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(ModelMap model, HttpSession session){
		
		session.invalidate();
		
		return "redirect:/";
		}
	
	@RequestMapping(value="/register", method = RequestMethod.GET)
	public String showRegisterPage(ModelMap model){
		return "register";
		}
	@RequestMapping(value="/userPage", method = RequestMethod.GET)
	public String showUserPage(ModelMap model){
		return "userPage";
		}
	@RequestMapping(value="/basket", method = RequestMethod.GET)
	public String showBasketPage(ModelMap model, HttpSession session){
		
		List<PartitaBasket> p = pbs.findAll();
		model.addAttribute("att", p);
		
		if(session.getAttribute("utente") == null) {
			
			Schedina schedina;
			if(session.getAttribute("schedina") == null) {
				schedina = new Schedina();
			}
			else {
				schedina = (Schedina)session.getAttribute("schedina");
			}
			session.setAttribute("schedina", schedina);
			model.addAttribute("schedina", schedina.getListaGiocate());
			model.addAttribute("quotaTot", schedina.getQuotaTotale());
			return "basket";
		}
		else {
			Utente u = (Utente)session.getAttribute("utente");
			Schedina s = (Schedina)session.getAttribute("schedina");
			model.addAttribute("utente", u);
			model.addAttribute("schedina", s.getListaGiocate());
			model.addAttribute("quotaTot", s.getQuotaTotale());
			return "basket";
		}
		}
		
		
	
	@RequestMapping(value="/hockey", method = RequestMethod.GET)
	public String showHockeyPage(ModelMap model, HttpSession session){
		
		List<PartitaHockey> p = phs.findAll();
		model.addAttribute("att", p);
		
		if(session.getAttribute("utente") == null) {
			
			Schedina schedina;
			if(session.getAttribute("schedina") == null) {
				schedina = new Schedina();
			}
			else {
				schedina = (Schedina)session.getAttribute("schedina");
			}
			session.setAttribute("schedina", schedina);
			model.addAttribute("schedina", schedina.getListaGiocate());
			model.addAttribute("quotaTot", schedina.getQuotaTotale());
			return "hockey";
		}
		else {
			Utente u = (Utente)session.getAttribute("utente");
			Schedina s = (Schedina)session.getAttribute("schedina");
			model.addAttribute("utente", u);
			model.addAttribute("schedina", s.getListaGiocate());
			model.addAttribute("quotaTot", s.getQuotaTotale());
			return "hockey";
		}
		}
		
	
	@RequestMapping(value="/riepilogo")
	public String showRiepilogoPage(Model model, HttpSession session) {
		
		Utente u = (Utente)session.getAttribute("utente");
		SchedinaFinale s = (SchedinaFinale)session.getAttribute("schedinaCorr");
		
		
		List<SchedinaFinale> sf = sfs.findByIdUtenteOrderByCodiceDesc(u.getId());
		int n = sf.size();
		
		List<LocalDate> sfd = sfs.findDistinctDataByIdUtente(u.getId());
		ArrayList<String> date = new ArrayList<String>();
		for(LocalDate localData : sfd) {
			String data;
			data = localData.toString();
			date.add("'"+data+"'");
		}
		
		List<Double> vincite = sfs.findWinByUtenteGroupByData(u.getId());
		

		model.addAttribute("utente", u);
		model.addAttribute("schedinaFin", sf);
		model.addAttribute("nScommesse", n);
		model.addAttribute("schedinaCorr", s);
		model.addAttribute("dati", vincite);
		model.addAttribute("date", date);
		
		
		return "riepilogo";
	}
	
	@RequestMapping(value="/ricaricasaldo")
	public String showRicaricaSaldoPage(Model model,HttpSession session) {
		Utente u=(Utente)session.getAttribute("utente");
		double saldo=u.getSaldo();
		
		model.addAttribute("utente",u);
		model.addAttribute("saldo",saldo);
		
		return "ricaricasaldo";
	}
	
	@RequestMapping(value="/utenti", method = RequestMethod.GET)
	public String showUtenti(ModelMap model, HttpSession session){
		
		List<Utente> u = us.findAll();
		model.addAttribute("att", u);
		return "utenti";

	}
	
	@RequestMapping(value="/adminPage", method = RequestMethod.GET)
	public String showAdmin(ModelMap model, HttpSession session){
		
		List<Admin> a = as.findAll();
		model.addAttribute("adm", a);
		return "adminPage";
	}
	
	@RequestMapping(value="/calcioAdmin", method = RequestMethod.GET)
	public String showCalcioAdmin(ModelMap model, HttpSession session){
		
		List<PartitaCalcio> p = pcs.findAll();
		model.addAttribute("admC", p);
		return "calcioAdmin";
	}
	
	@RequestMapping(value="/basketAdmin", method = RequestMethod.GET)
	public String showBasketAdmin(ModelMap model, HttpSession session){
		
		List<PartitaBasket> p = pbs.findAll();
		model.addAttribute("admB", p);
		return "basketAdmin";
	}
	
	@RequestMapping(value="/hockeyAdmin", method = RequestMethod.GET)
	public String showHockeyAdmin(ModelMap model, HttpSession session){
		
		List<PartitaHockey> p = phs.findAll();
		model.addAttribute("admH", p);
		return "hockeyAdmin";
	}
	
	@RequestMapping(value="/psswrdDimenticata", method = RequestMethod.GET)
	public String showPsswrdDimenticata(){
		return "psswrdDimenticata";
		}
	//AGGIUNGI QUESTO 
	@RequestMapping(value="/resetPassword", method = RequestMethod.GET)
	public String showResetPassword(ModelMap model,HttpSession session){
		model.addAttribute("emailReset",session.getAttribute("emailReset"));
		return "resetPassword";
		}

}